@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   ============================================
echo     두당 오프라인 실행 (인터넷 없이 사용)
echo   ============================================
echo.
echo   서버를 시작하고 브라우저를 자동으로 엽니다.
echo   이 검은 창은 닫지 마세요. (끝낼 때만 닫기)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0_server.ps1"
echo.
echo   서버가 종료되었습니다.
pause
