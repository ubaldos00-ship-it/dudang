# 두당 오프라인 로컬 서버 (윈도우 기본 PowerShell 사용 · 설치 불필요)
# 두당_오프라인_실행.bat 이 이 파일을 실행합니다. 직접 실행할 필요 없습니다.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8080
$listener = New-Object System.Net.HttpListener
try {
  $listener.Prefixes.Add("http://localhost:$port/"); $listener.Start()
} catch {
  $port = 8090
  $listener = New-Object System.Net.HttpListener
  $listener.Prefixes.Add("http://localhost:$port/"); $listener.Start()
}
Start-Process "http://localhost:$port/index.html"
Write-Host ""
Write-Host "  두당이 실행 중입니다:  http://localhost:$port" -ForegroundColor Green
Write-Host "  브라우저가 자동으로 열립니다. 끝내려면 이 창을 닫으세요."
Write-Host ""
$mime = @{
  '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8';
  '.js'='application/javascript; charset=utf-8'; '.mjs'='application/javascript; charset=utf-8';
  '.json'='application/json; charset=utf-8'; '.css'='text/css; charset=utf-8';
  '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.gif'='image/gif';
  '.svg'='image/svg+xml'; '.ico'='image/x-icon'; '.webmanifest'='application/manifest+json';
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.ttf'='font/ttf'
}
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.LocalPath)
    if ($rel -eq '/') { $rel = '/index.html' }
    $fp = Join-Path $root ($rel.TrimStart('/') -replace '/','\')
    if (Test-Path $fp -PathType Leaf) {
      $ext = [IO.Path]::GetExtension($fp).ToLower()
      $ct = $mime[$ext]; if (-not $ct) { $ct = 'application/octet-stream' }
      $bytes = [IO.File]::ReadAllBytes($fp)
      $ctx.Response.ContentType = $ct
      $ctx.Response.Headers.Add('Cache-Control','no-store')
      $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
      $ctx.Response.StatusCode = 404
    }
    $ctx.Response.Close()
  } catch { }
}
